<?php
// config/ably.php
return [
    'key' => env('ABLY_API_KEY', ''),
    'clientId' => env('ABLY_APP_ID', null),
];

